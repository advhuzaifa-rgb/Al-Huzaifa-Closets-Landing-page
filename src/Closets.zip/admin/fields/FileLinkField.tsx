// FileLinkField removed: kept as an inert stub to avoid accidental imports.
// This file is intentionally left as a no-op. The project no longer uses a
// custom admin field component for showing file links; the collection fields
// were updated to remove the custom component.

// Export a harmless stub so any lingering imports won't crash the build.
export default (null as unknown) as any
